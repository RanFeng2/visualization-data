Two Excel workbooks are included in this zip archive:

- co2sys.xls is for Excel versions 2003 or earlier (up to 65,536 rows)

- co2sys.xlsm is for Excel versions 2007 or later (up to 1,048,576 rows).
  Processing time for 1 million records is approximately
  4 minutes with CPU Intel Core i7 @ 2.40 GHz, or
  about 7 minutes with CPU Intel Core 2 duo @ 2.20 GHz.
 
Extract the zip archive before opening the Excel files.
Open the Excel files directly from Excel or Windows Explorer.
Do not open the file while it is still in the zip archive
because that will prevent the macro from running.